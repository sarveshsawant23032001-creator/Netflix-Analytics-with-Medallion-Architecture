# Databricks notebook source
spark

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

df = spark.read.format("delta")\
    .option("header", "true")\
    .option("inferSchema", "true")\
    .load("abfss://bronze@netflixprojectdlsarvesh.dfs.core.windows.net/netflix_titles")
display(df)

# COMMAND ----------

df = df.fillna({"duration_minutes": "0", "duration_seasons": "1"})
display(df)

# COMMAND ----------

df = df.withColumn("duration_minutes",col("duration_minutes").cast("int"))\
    .withColumn("duration_seasons",col("duration_seasons").cast("int"))

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df = df.withColumn("short_title",split(col("title"),':')[0])\
    .withColumn("rating",split("rating",'-')[0])\
        .withColumn("type_flag",when(col("type")=='Movie',1)\
            .when(col("type")=='TV Show',2).otherwise(0))
df.display()

# COMMAND ----------

from pyspark.sql.window import Window

df = df.withColumn("duration_rank",dense_rank().over(Window.orderBy(col("duration_minutes").desc())))
display(df)

# COMMAND ----------

df_vis = df.groupBy("type").agg(count("*").alias("total_count"))
df_vis.display()

# COMMAND ----------

df.write.format("delta").mode("overwrite").option("path","abfss://silver@netflixprojectdlsarvesh.dfs.core.windows.net/netflix_titles").save()